﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prova_Dalilo_FelipeCurti
{
    public partial class Form2 : Form
    {
        int indice = 0;
        public Form2()
        {
            InitializeComponent();
        }

        private void BtnAvancar_Click(object sender, EventArgs e)
        {
            indice++;

            if (indice == 1)
            {
                label1.ImageIndex = indice;
                label2.Text = "Sorvetes";
            }
            if (indice == 2)
            {
                label1.ImageIndex = indice;
                label2.Text = "Churrasco";
            }
            if (indice == 3)
            {
                label1.ImageIndex = indice;
                label2.Text = "Salgados";
            }
            if (indice == 4)
            {
                label1.ImageIndex = indice;
                label2.Text = "Doces";
            }
            if (indice == 5)
            {
                label1.ImageIndex = indice;
                label2.Text = "Prato feito";
            }
            if (indice == 6)
            {
                label1.ImageIndex = indice;
                label2.Text = "Comida Típicas Brasileira";
            }
            if (indice == 7)
            {
                label1.ImageIndex = indice;
                label2.Text = "Lanches";
            }
            if (indice == 8)
            {
                label1.ImageIndex = indice;
                label2.Text = "Massas";
            }
            if (indice > 8)
            {
                indice = 0;
                label1.ImageIndex = indice;
                label2.Text = "Bebidas";
            }
        }

        private void BtnVoltar_Click(object sender, EventArgs e)
        {
            indice--;
            label1.ImageIndex = indice;
            if (indice < 0)
            {
                MessageBox.Show("Cardápio não iniciado.", "Erro");
            }
            if (indice == 0)
            {
                label1.ImageIndex = indice;
                label2.Text = "Bebidas";
            }
            if (indice == 1)
            {
                label1.ImageIndex = indice;
                label2.Text = "Sorvetes";
            }
            if (indice == 2)
            {
                label1.ImageIndex = indice;
                label2.Text = "Churrasco";
            }
            if (indice == 3)
            {
                label1.ImageIndex = indice;
                label2.Text = "Salgados";
            }
            if (indice == 4)
            {
                label1.ImageIndex = indice;
                label2.Text = "Doces";
            }
            if (indice == 5)
            {
                label1.ImageIndex = indice;
                label2.Text = "Prato feito";
            }
            if (indice == 6)
            {
                label1.ImageIndex = indice;
                label2.Text = "Comida Típicas Brasileira";
            }
            if (indice == 7)
            {
                label1.ImageIndex = indice;
                label2.Text = "Lanches";
            }
            if (indice == 8)
            {
                label1.ImageIndex = indice;
                label2.Text = "Massas";
            }
        }

        private void Label3_Click(object sender, EventArgs e)
        {
            if (indice == 0)
            {
                label1.Text = "Bebidas";
            }
            if (indice == 1)
            {
                label1.Text = "Sorvetes";
            }
            if (indice == 2)
            {
                label1.Text = "Churrasco";
            }
            if (indice == 3)
            {
                label1.Text = "Salgados";
            }
            if (indice == 4)
            {
                label1.Text = "Doces";
            }
            if (indice == 5)
            {
                label1.Text = "Prato feito";
            }
            if (indice == 6)
            {
                label1.Text = "Comida Típicas Brasileira";
            }
            if (indice == 7)
            {
                label1.Text = "Lanches";
            }
            if (indice == 8)
            {
                label1.Text = "Massas";
            }
        }

        private void Label1_Click(object sender, EventArgs e)
        {
            if (indice == 0)
            {
                MessageBox.Show("Você escolheu Bebidas, obrigado!");
            }
            if (indice == 1)
            {
                MessageBox.Show("Você escolheu Sorvetes, obrigado!");
            }
            if (indice == 2)
            {
                MessageBox.Show("Você escolheu Churrasco, obrigado!");
            }
            if (indice == 3)
            {
                MessageBox.Show("Você escolheu Salgados, obrigado!");
            }
            if (indice == 4)
            {
                MessageBox.Show("Você escolheu Doces, obrigado!");
            }
            if (indice == 5)
            {
                MessageBox.Show("Você escolheu Prato Feito, obrigado!");
            }
            if (indice == 6)
            {
                MessageBox.Show("Você escolheu Comida Típica Brasileira, obrigado!");
            }
            if (indice == 7)
            {
                MessageBox.Show("Você escolheu Lanches, obrigado!");
            }
            if (indice == 8)
            {
                MessageBox.Show("Você escolheu Massas, obrigado!");
            }
        }
    }
}
